<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Create List</name>
   <tag></tag>
   <elementGuidId>406f430c-5e66-4ce4-a57b-295b9586591d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='wl-redesigned-create-list']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#wl-redesigned-create-list > span.a-button.a-button-primary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ba7d3272-88bc-432f-8fee-db7d4dae2f46</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-button a-button-primary</value>
      <webElementGuid>cfe5a44f-2086-4e66-b45a-a09f2e416d2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Create List</value>
      <webElementGuid>3ed5e5d7-db35-4bac-9090-0f4af246afed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wl-redesigned-create-list&quot;)/span[@class=&quot;a-button a-button-primary&quot;]</value>
      <webElementGuid>aecef2c3-c6c7-40c6-9f48-a9c120e633a5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[@id='wl-redesigned-create-list']/span</value>
      <webElementGuid>02a162a9-dafd-4216-a887-787154d275db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[3]/span[3]/span</value>
      <webElementGuid>852d6136-c993-4943-8f6f-4ea6532f40dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Create List' or . = 'Create List')]</value>
      <webElementGuid>e9a40bc6-b228-4f5a-8259-2b07479950a0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
